function Fix-File {
    param ($FilePath)
    $in = Import-Csv -Delimiter ';' $FilePath

    Write-Output "Fixing $FilePath"

    $out = ForEach ($entry in $in) {
        $entry."time_limit" = "120"
        $entry
    }

    $out | Export-Csv -Delimiter ';' $FilePath
}

$files = Get-ChildItem -File trial*

foreach ($file in $files) {
    Fix-File $file.FullName
}